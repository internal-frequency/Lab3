import InstructorList from './Components/InstructorList';




function App() {
  return (
   <div>
   <h1>List of instructors:</h1>
   
    <InstructorList/>
    
  
   </div>
  );
}

export default App;

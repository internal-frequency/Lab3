import React from 'react'
import './myStyle.css'


function Instructor({instructor}) {
  return (
    <div class = 'instructor' style = {{color:instructor.status === "true" ? 'green' : 'red'}}>
      
         <h2> 
         <li>Name:{instructor.name} <br></br></li>
          Age: {instructor.age} <br></br>
          City: {instructor.city} <br></br>
          Status of teaching in spring? {instructor.status} 
          </h2>
    </div>

  

    
  )

}

export default Instructor